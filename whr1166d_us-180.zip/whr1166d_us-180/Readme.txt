***********************************************************************
*                                                                     *
*      WHR-1166D User-friendly Firmware                               *
*                                                                     *
*                                      Copyright(C) 2015 BUFFALO Inc. *
*                                                                     *
***********************************************************************

File contents

Readme.txt               This file
how_to_update_us.html    Firmware update instruction
images\***               Image data for howto_update.html
whr1166d_us_180          WHR-1166D  Ver1.80 firmware file

The howto_update.html describes how to update firmware.
Please review it by WEB browser.

------------------------------------------------------------------------
- The Software is protected by copyright and other intellectual property
  laws and international treaty provisions.
- Windows is registered trademark of Microsoft Corporation in United States.
                                                            Buffalo Inc.
------------------------------------------------------------------------
